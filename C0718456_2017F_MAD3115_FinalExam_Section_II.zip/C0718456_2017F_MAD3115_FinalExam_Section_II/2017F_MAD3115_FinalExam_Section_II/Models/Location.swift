//
//  Location.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    :
//  Name        :

import Foundation
import MapKit
class Location
{
    
    let locationName : String!
    let coordinate : CLLocationCoordinate2D
    init(locationName: String, coordinate: CLLocationCoordinate2D)
    {
        self.locationName = locationName
        self.coordinate = coordinate
    }
    
    
}
