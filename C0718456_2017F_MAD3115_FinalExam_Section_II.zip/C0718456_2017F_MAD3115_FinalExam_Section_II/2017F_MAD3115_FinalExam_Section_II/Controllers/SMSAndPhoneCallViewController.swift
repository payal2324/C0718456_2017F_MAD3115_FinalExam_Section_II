//
//  ViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : C0718456
//  Name        : Payal Khosla

import UIKit
import MessageUI
class SMSAndPhoneCallViewController: UIViewController,MFMessageComposeViewControllerDelegate{
   
    var result : String!
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        
//        switch(result)
//        {
//        case : cancel
//        print("Call Cancelled")
//        case:      }
//
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func actionBtnMsg(_ sender: UIButton)
    {
        if(MFMessageComposeViewController.canSendText())
        {
            print("can send text")
//            let msgObj = MFMessageComposeViewController()
//            msgObj.messageComposeDelegate = self
//            msgObj.recipients = ["+435675567"]
//            msgObj.body = "Hello, How are you ?"
//            print("text sent")
//            self.present(msgObj, animated: false, completion: nil)
//        print("text sent")
        }
        
        
        
        
        
    }
    
    @IBAction func actionBtnPhone(_ sender: UIButton)
    {
 
        if let url = URL(string: "tel:// +1456765567"), UIApplication.shared.canOpenURL(url)
        {
            if #available(iOS 10, *)
            {
            UIApplication.shared.open(url)
            }
            else
            {
            UIApplication.shared.openURL(url)
            }
        }
    
    }
    
}

