//
//  SendEmailViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : C0718456
//  Name        : Payal Khosla

import UIKit
import MessageUI
class SendEmailViewController: UIViewController,MFMailComposeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    
    
    
    @IBAction func actionBtnSendEmail(_ sender: UIButton)
    
    {
    let email = MFMailComposeViewController()
        if (MFMailComposeViewController.canSendMail())
        {
        email.setSubject("Subject of email")
        email.setCcRecipients(["xyz@gmail.com"])
        email.setMessageBody("sending good wishes", isHTML: true)
        self.present(email, animated: true, completion: nil)
        
        }
    }
    
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
    controller.dismiss(animated: true, completion: nil)
    }
  

}
