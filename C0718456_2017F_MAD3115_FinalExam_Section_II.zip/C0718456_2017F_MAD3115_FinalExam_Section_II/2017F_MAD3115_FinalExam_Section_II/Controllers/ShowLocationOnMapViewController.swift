//
//  ShowLocationOnMapViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : C0718456
//  Name        : Payal Khosla

import UIKit
import MapKit
class ShowLocationOnMapViewController: UIViewController,MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    

        @IBOutlet weak var mapView: MKMapView!
        override func viewDidLoad() {
        super.viewDidLoad()
        let initialLocation = CLLocation(latitude: 43.7733, longitude: 79.3359)
    
        
        let regionRadius: CLLocationDistance = 1000
        func centerMapOnLocation(location: CLLocation)
        {
            let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,regionRadius, regionRadius)
            mapView.setRegion(coordinateRegion, animated: true)
            centerMapOnLocation(location: initialLocation)
            
        }
        
        
        
        func setLocation()
        {
        let location = Location(locationName: "CN Tower",coordinate: CLLocationCoordinate2D(latitude: 43.6426, longitude:79.3871))
            mapView.addAnnotation(location as! MKAnnotation)
        
        }
        
        
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
